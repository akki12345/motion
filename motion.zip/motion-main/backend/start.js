// start.js
const { server } = require('./server');

const PORT = process.env.PORT || 3003;

server.listen(PORT, async () => {
  console.log(`🚀 WebSocket server running on http://localhost:${PORT}`);
  
  // Import forwarder after server is running
  const { TelegramForwarder } = require('./forwarder');
  const CONFIG = require('./config');
  const { setStatus } = require('./server');
  
  console.log('\n╔═══════════════════════════════════════╗');
  console.log('║  Telegram Channel Auto-Forwarder      ║');
  console.log('╚═══════════════════════════════════════╝\n');

  // Validate config
  if (!CONFIG.apiId || CONFIG.apiId === 0 || !CONFIG.apiHash || CONFIG.apiHash === 'YOUR_API_HASH') {
    console.error('❌ Please configure your API credentials in config.js!');
    console.error('   Get them from: https://my.telegram.org');
    process.exit(1);
  }

  if (!CONFIG.destinationChannel || CONFIG.destinationChannel === '@your_channel_username') {
    console.error('❌ Please configure your destination channel in config.js!');
    process.exit(1);
  }

  if (!CONFIG.sourceChannels || CONFIG.sourceChannels.length === 0) {
    console.error('❌ Please add source channels to monitor in config.js!');
    process.exit(1);
  }

  const forwarder = new TelegramForwarder(CONFIG);
  
  try {
    await forwarder.initialize();
    await forwarder.start();
  } catch (err) {
    console.error('❌ Fatal error:', err);
    setStatus('ERROR');
    process.exit(1);
  }
});