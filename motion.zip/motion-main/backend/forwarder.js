const { TelegramClient } = require('telegram');
const { StringSession } = require('telegram/sessions');
const { NewMessage } = require('telegram/events');
const input = require('input');

// Import WebSocket server
const { updateStats, addMessage, setStatus, updateMessageStatus } = require('./server');

// ============ CONFIGURATION ============
const CONFIG = require('./config');
const DEBUG = process.env.DEBUG === 'true';
const STATS_INTERVAL = 60000; // 60 seconds

// ============ MESSAGE QUEUE ============
class MessageQueue {
  constructor(config) {
    this.queue = [];
    this.processing = false;
    this.config = config;
    this.lastSentTime = 0;
    this.sentInLastSecond = 0;
    this.secondStartTime = Date.now();
  }

  add(message) {
    this.queue.push(message);
    if (DEBUG) console.log(`📥 Message queued. Queue size: ${this.queue.length}`);
    
    // Update queue size
    updateStats({ queueSize: this.queue.length });

    if (!this.processing) {
      this.process();
    }
  }

  async process() {
    if (this.processing || this.queue.length === 0) return;
    
    this.processing = true;

    while (this.queue.length > 0) {
      const now = Date.now();
      
      // Reset counter if a second has passed
      if (now - this.secondStartTime >= 1000) {
        this.sentInLastSecond = 0;
        this.secondStartTime = now;
      }

      // Check rate limit
      if (this.sentInLastSecond >= this.config.messagesPerSecond) {
        const waitTime = 1000 - (now - this.secondStartTime);
        if (DEBUG) console.log(`⏳ Rate limit reached. Waiting ${waitTime}ms...`);
        await this.sleep(waitTime);
        this.sentInLastSecond = 0;
        this.secondStartTime = Date.now();
        continue;
      }

      const item = this.queue.shift();
      
      try {
        await item.forward();
        this.sentInLastSecond++;
        this.lastSentTime = Date.now();
        if (DEBUG) console.log(`✅ Message forwarded. Queue remaining: ${this.queue.length}`);

        // Update queue size
        updateStats({ queueSize: this.queue.length });
        
        // Delay between messages
        if (this.queue.length > 0) {
          await this.sleep(this.config.delayBetweenMessages);
        }
      } catch (err) {
        if (err.message.includes('FLOOD_WAIT')) {
          const waitSeconds = err.seconds || parseInt(err.message.match(/\d+/)?.[0]) || 60;
          console.error(`🚫 FloodWait error! Waiting ${waitSeconds} seconds...`);
          this.queue.unshift(item); // Put message back
          await this.sleep(waitSeconds * 1000);
        } else {
          console.error(`❌ Error forwarding message:`, err.message);
        }
      }
    }

    this.processing = false;
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ============ MESSAGE FILTER ============
class MessageFilter {
  constructor(config) {
    this.config = config;
  }

  shouldForward(message) {
    // Check if message has content
    if (!message.message && !message.media && !message.poll) {
      return false;
    }

    const text = message.message || '';

    // Check minimum length
    if (text.length < this.config.minTextLength) {
      return false;
    }

    // Check media
    if (message.media && !this.config.allowMedia) {
      return false;
    }

    // Check polls
    if (message.poll && !this.config.allowPolls) {
      return false;
    }

    // Check keywords (include)
    if (this.config.keywords.length > 0) {
      const hasKeyword = this.config.keywords.some(kw => 
        text.toLowerCase().includes(kw.toLowerCase())
      );
      if (!hasKeyword) return false;
    }

    // Check keywords (exclude)
    if (this.config.excludeKeywords.length > 0) {
      const hasExcluded = this.config.excludeKeywords.some(kw =>
        text.toLowerCase().includes(kw.toLowerCase())
      );
      if (hasExcluded) return false;
    }

    return true;
  }
}

// ============ MAIN APPLICATION ============
class TelegramForwarder {
  constructor(config) {
    this.config = config;
    this.client = null;
    this.queue = new MessageQueue(config.rateLimits);
    this.filter = new MessageFilter(config.filters);
    this.stats = {
      received: 0,
      forwarded: 0,
      filtered: 0,
      errors: 0
    };
  }

  async initialize() {
    console.log('🚀 Initializing Telegram client...');
    setStatus('CONNECTING');
    
    const session = new StringSession(this.config.sessionString); 
    
    this.client = new TelegramClient(
      session,
      this.config.apiId,
      this.config.apiHash,
      {
        connectionRetries: 5,
      }
    );

    await this.client.start({
      phoneNumber: async () => await input.text('Enter your phone number: '),
      password: async () => await input.text('Enter your password (if 2FA): '),
      phoneCode: async () => await input.text('Enter the code you received: '),
      onError: (err) => console.error('❌ Login error:', err),
    });

    console.log('✅ Connected to Telegram!');
    if (!this.config.sessionString) {
      console.log('📱 Session string (save this in config.js):');
      console.log(this.client.session.save());
      console.log('');
    } else {
      console.log('📱 Using saved session');
    }
    setStatus('CONNECTED');
  }

  async validateChannels() {
    console.log('\n🔍 Validating channels...');
    
    // Try to get destination entity
    try {
      const dest = await this.client.getEntity(this.config.destinationChannel);
      console.log(`✓ Destination: ${dest.title}`);
    } catch (err) {
      console.error(`✗ Cannot access destination channel: ${this.config.destinationChannel}`);
      throw new Error('Invalid destination channel');
    }
    
    // Validate each source channel
    const validChannels = [];
    for (const channel of this.config.sourceChannels) {
      try {
        const entity = await this.client.getEntity(channel);
        console.log(`✓ Source: ${entity.title || channel}`);
        validChannels.push(entity);
      } catch (err) {
        console.error(`✗ Cannot access: ${channel} - ${err.message}`);
      }
    }
    
    if (validChannels.length === 0) {
      throw new Error('No valid source channels found!');
    }
    
    console.log(`\n✅ Validated ${validChannels.length}/${this.config.sourceChannels.length} channels\n`);
    return validChannels;
  }

  async start() {
    console.log('\n🎯 Starting channel monitor...');
    const validChannels = await this.validateChannels();
    console.log(`📡 Monitoring ${validChannels.length} channels`);
    console.log(`📤 Forwarding to: ${this.config.destinationChannel}\n`);

    setStatus('ACTIVE');

    // Send initial stats
    updateStats(this.stats);

    // Register event handler for new messages
    this.client.addEventHandler(
      this.handleNewMessage.bind(this),
      new NewMessage({
        chats: this.config.sourceChannels,
      })
    );

    console.log('✅ Monitoring active! Press Ctrl+C to stop.\n');
    
    // Keep the script running
    process.on('SIGINT', async () => {
      console.log('\n\n📊 Final Statistics:');
      console.log(`   Received: ${this.stats.received}`);
      console.log(`   Forwarded: ${this.stats.forwarded}`);
      console.log(`   Filtered: ${this.stats.filtered}`);
      console.log(`   Errors: ${this.stats.errors}`);
      console.log('\n👋 Shutting down...');
      setStatus('DISCONNECTED');
      process.exit(0);
    });

    // Print stats every minute
    setInterval(() => {
      console.log(`\n📊 Stats | Received: ${this.stats.received} | Forwarded: ${this.stats.forwarded} | Filtered: ${this.stats.filtered} | Errors: ${this.stats.errors} | Queue: ${this.queue.queue.length}`);
    }, STATS_INTERVAL);
  }

  async handleNewMessage(event) {
    this.stats.received++;
    
    const message = event.message;
    
    // Get chat info safely
    let chatName = 'Unknown';
    try {
      const chat = await event.getChat();
      chatName = chat.title || chat.username || chat.firstName || `ID: ${chat.id}`;
    } catch (err) {
      // Fallback: try to get entity from peerId
      try {
        const entity = await this.client.getEntity(message.peerId);
        chatName = entity.title || entity.username || entity.firstName || `ID: ${entity.id}`;
      } catch (e) {
        // Last resort: use the peer ID
        chatName = `Channel ID: ${message.peerId.channelId || message.peerId.userId || 'Unknown'}`;
      }
    }

    if (DEBUG) console.log(`\n📨 New message from: ${chatName}`);

    // Apply filters
    if (!this.filter.shouldForward(message)) {
      if (DEBUG) console.log(`🚫 Message filtered out`);
      this.stats.filtered++;
      updateStats(this.stats); 
      return;
    }
    const messageId = `${Date.now()}-${message.id}`;
    // Send message to frontend
    addMessage({
      id: messageId,
      source: chatName,
      text: message.message || '[Media/Poll]',
      timestamp: new Date(),
      status: "queued",
      media: !!message.media
    });

    // Add to queue
    this.queue.add({
      forward: async () => {
        try {
          await this.client.forwardMessages(
            this.config.destinationChannel,
            {
              messages: [message.id],
              fromPeer: message.peerId,
            }
          );
          this.stats.forwarded++;
          updateStats(this.stats);
          updateMessageStatus(messageId, 'sent');
        } catch (error) {
          console.error(`❌ Failed to forward message ${messageId}:`, error.message);
          this.stats.errors++;
          updateStats(this.stats);
          updateMessageStatus(messageId, 'failed');
          throw error;
        }
      }
    });
  }
}

module.exports = { TelegramForwarder, MessageQueue, MessageFilter };