const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
const server = http.createServer(app);

// Configure Socket.io with CORS
const io = new Server(server, {
  cors: {
    origin: ["http://localhost:3000", "http://localhost:3001"], // Add your React port
    methods: ["GET", "POST"],
    credentials: true
  }
});

// Middleware
app.use(cors({
  origin: ["http://localhost:3000", "http://localhost:3001"],
  credentials: true
}));
app.use(express.json());

// Store stats and messages
let stats = {
  received: 0,
  forwarded: 0,
  filtered: 0,
  errors: 0,      
  queueSize: 0,
  status: 'CONNECTING'
};

let messages = [];
const MAX_MESSAGES = 50;

// REST API endpoints
app.get('/api/stats', (req, res) => {
  try {
    res.json(stats);
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/messages', (req, res) => {
  try {
    res.json(messages);
  } catch (error) {
    console.error('Error fetching messages:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/config', (req, res) => {
  try {
    const CONFIG = require('./config');
    // Don't expose sensitive data
    res.json({
      destinationChannel: CONFIG.destinationChannel,
      sourceChannelsCount: CONFIG.sourceChannels.length,
      rateLimits: CONFIG.rateLimits
    });
  } catch (error) {
    console.error('Error fetching config:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Socket.io connection
io.on('connection', (socket) => {
  console.log('✅ Frontend connected:', socket.id);

  // Send initial data
  socket.emit('initial-data', {
    stats,
    messages,
  });

  socket.on('disconnect', () => {
    console.log('❌ Frontend disconnected:', socket.id);
  });
});

// Export functions to update data from forwarder
function updateStats(newStats) {
  stats = { ...stats, ...newStats };
  io.emit('stats-update', stats);
//   console.log(stats);
}

function addMessage(message) {
  messages.unshift(message);
  if (messages.length > MAX_MESSAGES) {
    messages = messages.slice(0, MAX_MESSAGES);
  }
  io.emit('new-message', message);
//   console.log(message);
}

function setStatus(status) {
  stats.status = status;
  io.emit('stats-update', stats);
//   console.log(stats);
}

function updateMessageStatus(messageId, status) {
  const message = messages.find(m => m.id === messageId);
  if (message) {
    message.status = status;
    io.emit('message-update', { id: messageId, status });
  }
}

// Graceful shutdown
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

function shutdown() {
  console.log('\n🛑 Shutting down gracefully...');
  io.close(() => {
    server.close(() => {
      console.log('✅ Server closed');
      process.exit(0);
    });
  });
}

module.exports = { updateStats, addMessage, setStatus, updateMessageStatus, io, server };