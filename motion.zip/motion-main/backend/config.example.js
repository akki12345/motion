// config.js
module.exports = {
  apiId: 12345678,  // Your actual API ID (number)
  apiHash: 'your_actual_api_hash_here',  // Your actual API hash
  sessionString: '',  // Add saved session after first login
  
  // Your destination channel (username or ID)
  destinationChannel: '@your_channel_username',
  
  // Source channels to monitor (usernames or IDs)
  sourceChannels: [
    '@source_channel_1',
    '@source_channel_2',
    '@source_channel_3',
    // Add up to 100 channels...
  ],
  
  // Rate limiting settings
  rateLimits: {
    messagesPerSecond: 2,
    burstSize: 10,
    delayBetweenMessages: 500,
  },
  
  // Optional: filter settings
  filters: {
    minTextLength: 0,
    allowMedia: true,
    allowPolls: true,
    keywords: [],
    excludeKeywords: [],
  }
};