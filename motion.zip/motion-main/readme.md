# Telegram Channel Auto-Forwarder

Automatically forward messages from multiple Telegram channels to your own channel with a real-time dashboard.

## Prerequisites

- Node.js (v14 or higher) - [Download](https://nodejs.org/)
- Telegram API credentials from [my.telegram.org](https://my.telegram.org)

## Installation

```bash
# Install all dependencies (backend + frontend)
npm run install:all

# Or install separately
npm run install:backend
npm run install:frontend
```

## Setup

### 1. Get Telegram API Credentials

1. Visit https://my.telegram.org
2. Login with your phone number
3. Go to "API development tools"
4. Create a new application
5. Copy your `api_id` and `api_hash`

### 2. Configure Backend

1. Rename `backend/config.example.js` to `backend/config.js`
2. Add your credentials:
   - `apiId` - must be a NUMBER (no quotes)
   - `apiHash` - your API hash string
   - `destinationChannel` - your channel username with @ symbol
   - `sourceChannels` - array of source channel usernames

**Note:** Join all source channels and ensure you're admin of the destination channel.

### 3. First Login

```bash
cd backend
node start.js
```

Follow the prompts to login. After login, copy the **session string** and paste it into `config.js`:

```javascript
sessionString: 'paste_your_session_string_here',
```

## Running

### Option 1: Run Both (Recommended)

```bash
npm run dev
```

- Backend runs on default port
- Frontend opens at http://localhost:3000

### Option 2: Run Separately

**Backend only:**
```bash
npm run start:backend
# or
cd backend && node start.js
```

**Frontend only:**
```bash
npm run start:frontend
# or
cd frontend && npm start
```

## Stopping

Press `Ctrl+C` to stop. The backend will display final statistics before exiting.

## Troubleshooting

**"Cannot access channel"**
- Ensure you've joined the channel
- Verify the username is correct with @ symbol

**"Invalid destination channel"**
- Confirm you're an admin of the destination channel

**Login issues**
- `apiId` must be a number without quotes
- Delete `sessionString` and login again if needed

**Frontend not connecting**
- Ensure backend is running first
- Check browser console for errors
