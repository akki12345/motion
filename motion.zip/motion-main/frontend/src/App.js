import React, { useState, useEffect, useRef } from 'react';
import { io } from 'socket.io-client'; // 1. Import Socket.io client
import { Activity, Radio, Send, Filter, TrendingUp, AlertCircle } from 'lucide-react';

const TelegramForwarderDashboard = () => {
  const [messages, setMessages] = useState([]);
  const [stats, setStats] = useState({
    received: 0,
    forwarded: 0,
    filtered: 0,
    errors: 0,
    queueSize: 0,
    status: 'CONNECTING'
  });
  const [config, setConfig] = useState({
    destinationChannel: '@your_channel',
    sourceChannels: ['@source1', '@source2', '@source3'],
    rateLimits: { messagesPerSecond: 2 }
  });
  const messagesEndRef = useRef(null);

useEffect(() => {
  console.log('🔌 Attempting to connect to backend...');
  
  // Connect to backend socket server
  const socket = io('http://localhost:3003', {
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionAttempts: 5
  });
  
  // Connection event handlers
  socket.on('connect', () => {
    console.log('✅ Socket connected! ID:', socket.id);
  });
  
  socket.on('connect_error', (error) => {
    console.error('❌ Socket connection error:', error.message);
  });
  
  socket.on('disconnect', (reason) => {
    console.log('🔌 Socket disconnected:', reason);
  });
  
  // Listen for initial data
  socket.on('initial-data', (data) => {
    console.log('📥 Received initial data:', data);
    console.log('📊 Stats received:', data.stats);
    // setStats(data.stats);
    setStats(prevStats => ({
      ...prevStats,
      ...data.stats
    }));
    // Convert timestamps for existing messages
    setMessages(data.messages.map(msg => ({
      ...msg,
      timestamp: new Date(msg.timestamp)
    })));
  });
  
  // Listen for stats update
  socket.on('stats-update', (updatedStats) => {
    console.log('📊 Stats update:', updatedStats);
    setStats(prevStats => ({
      ...prevStats,
      ...updatedStats
    }));
  });
  
  // Listen for new messages
  socket.on('new-message', (newMessage) => {
    console.log('📨 New message:', newMessage);
    setMessages(prev => [{
      ...newMessage,
      timestamp: new Date(newMessage.timestamp)
    }, ...prev.slice(0, 49)]);
  });
  
  // Listen for message status updates
  socket.on('message-update', (update) => {
    console.log('🔄 Message status update:', update);
    setMessages(prev => prev.map(msg => 
      msg.id === update.id ? { ...msg, status: update.status } : msg
    ));
  });
  
  // Fetch config from backend
  console.log('🔍 Fetching config...');
  fetch('http://localhost:3003/api/config')
    .then(res => {
      console.log('📡 Config response status:', res.status);
      return res.json();
    })
    .then(data => {
      console.log('⚙️ Config data:', data);
      setConfig({
        destinationChannel: data.destinationChannel,
        sourceChannels: [`${data.sourceChannelsCount} channels monitored`],
        rateLimits: data.rateLimits
      });
    })
    .catch(err => console.error('❌ Failed to fetch config:', err));
  
  // Clean up on unmount
  return () => {
    console.log('🧹 Cleaning up socket connection');
    socket.disconnect();
  };
}, []);

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    });
  };

  const successRate = stats.received > 0 ? ((stats.forwarded / stats.received) * 100).toFixed(1) : 0;

  return (
    <div className="min-h-screen bg-gray-50" style={{ fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold" style={{ fontFamily: 'Georgia, serif' }}>
                Telegram <span className="font-normal">Forwarder</span>
              </h1>
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${stats.status === 'ACTIVE' ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                <span className="text-sm font-medium text-gray-700">{stats.status}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-8">
            <button className="py-3 text-sm font-semibold border-b-2 border-black">
              LIVE
            </button>
            <button className="py-3 text-sm font-medium text-gray-500 hover:text-gray-900">
              ANALYTICS
            </button>
            <button className="py-3 text-sm font-medium text-gray-500 hover:text-gray-900">
              SETTINGS
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold uppercase tracking-wider">OVERALL STATS</h2>
            <div className="flex gap-2">
              <button className="px-3 py-1 text-xs font-semibold bg-black text-white">
                ALL
              </button>
              <button className="px-3 py-1 text-xs font-medium text-gray-600 border border-gray-300">
                72H
              </button>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-4">
            <div className="bg-white border border-gray-200 p-6">
              <div className="text-xs font-semibold text-gray-500 mb-2 uppercase tracking-wide">Total Received</div>
              <div className="text-3xl font-normal mb-1">{stats.received.toLocaleString()}</div>
              <div className="text-sm text-green-600 font-medium">+{successRate}%</div>
            </div>
            <div className="bg-white border border-gray-200 p-6">
              <div className="text-xs font-semibold text-gray-500 mb-2 uppercase tracking-wide">Forwarded</div>
              <div className="text-3xl font-normal mb-1">{stats.forwarded.toLocaleString()}</div>
              <div className="text-sm text-green-600 font-medium">+{Math.max(0, stats.forwarded - stats.filtered)}%</div>
            </div>
            <div className="bg-white border border-gray-200 p-6">
              <div className="text-xs font-semibold text-gray-500 mb-2 uppercase tracking-wide">Filtered Out</div>
              <div className="text-3xl font-normal mb-1">{stats.filtered.toLocaleString()}</div>
              <div className="text-sm text-red-600 font-medium">-{((stats.filtered / Math.max(1, stats.received)) * 100).toFixed(1)}%</div>
            </div>
            <div className="bg-white border border-gray-200 p-6">
              <div className="text-xs font-semibold text-gray-500 mb-2 uppercase tracking-wide">Queue Size</div>
              <div className="text-3xl font-normal mb-1">{stats.queueSize}</div>
              <div className="text-sm text-gray-500 font-medium">{config.rateLimits.messagesPerSecond}/sec</div>
            </div>
          </div>
        </div>

        {/* Configuration Card */}
        <div className="bg-white border border-gray-200 p-6 mb-8">
          <h3 className="text-sm font-bold uppercase tracking-wider mb-4">Configuration</h3>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Destination Channel</div>
              <div className="flex items-center gap-2">
                <Send className="w-4 h-4 text-blue-600" />
                <span className="font-medium">{config.destinationChannel}</span>
              </div>
            </div>
            <div>
              <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
                Source Channels
              </div>
              <div className="flex flex-wrap gap-2">
                {config.sourceChannels.map((channel, i) => (
                  <span key={i} className="text-sm px-2 py-1 bg-gray-100 border border-gray-200 font-medium">
                    {channel}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Messages Feed */}
        <div className="bg-white border border-gray-200">
          <div className="border-b border-gray-200 p-4 flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider">Live Message Feed</h3>
            <span className="text-xs text-gray-500 uppercase">Last 50 Messages</span>
          </div>
          
          {/* Table Header */}
          <div className="border-b border-gray-200 bg-gray-50">
            <div className="grid grid-cols-12 gap-4 px-4 py-3 text-xs font-semibold text-gray-600 uppercase tracking-wide">
              <div className="col-span-1">Time</div>
              <div className="col-span-2">Source</div>
              <div className="col-span-6">Message</div>
              <div className="col-span-1">Type</div>
              <div className="col-span-2">Status</div>
            </div>
          </div>

          <div className="divide-y divide-gray-200 max-h-96 overflow-y-auto">
            {messages.length === 0 ? (
              <div className="flex items-center justify-center py-12 text-gray-400">
                Waiting for messages...
              </div>
            ) : (
              messages.map((msg, idx) => (
                <div 
                  key={msg.id} 
                  className="grid grid-cols-12 gap-4 px-4 py-3 hover:bg-gray-50 transition-colors"
                >
                  <div className="col-span-1 text-sm text-gray-600 font-medium">
                    {formatTime(msg.timestamp)}
                  </div>
                  <div className="col-span-2 text-sm font-medium text-blue-600">
                    {msg.source}
                  </div>
                  <div className="col-span-6 text-sm text-gray-700">
                    {msg.text}
                  </div>
                  <div className="col-span-1 text-xs">
                    {msg.media ? (
                      <span className="px-2 py-1 bg-purple-100 text-purple-700 font-semibold rounded">
                        MEDIA
                      </span>
                    ) : (
                      <span className="px-2 py-1 bg-gray-100 text-gray-600 font-semibold rounded">
                        TEXT
                      </span>
                    )}
                  </div>
                  <div className="col-span-2">
                    {msg.status === 'sent' || msg.status === 'forwarded' ? (
  <div className="flex items-center gap-2">
    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
    <span className="text-sm font-semibold text-green-600">FORWARDED</span>
  </div>
                    ) : msg.status === 'queued' ? (
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                        <span className="text-sm font-semibold text-yellow-600">QUEUED</span>
                      </div>
                    ) : msg.status === 'failed' ? (
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        <span className="text-sm font-semibold text-red-600">FAILED</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        <span className="text-sm font-semibold text-red-600">FILTERED</span>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Footer Note */}
        <div className="mt-6 text-sm text-gray-500">
          <span className="font-semibold">Note:</span> All statistics reflect real-time data. Success rate calculated as forwarded/received messages.
        </div>
      </div>
    </div>
  );
};

export default TelegramForwarderDashboard;